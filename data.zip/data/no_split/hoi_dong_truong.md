# Hội đồng Trường Đại học Cần Thơ
# Thường trực
1. GS.TS. Nguyễn Thanh Phương – Chủ tịch Hội đồng Trường, Bí thư Đảng ủy
2. PGS.TS. Trần Trung Tính – Thường trực Hội đồng Trường
3. PGS.TS. Nguyễn Chí Ngôn – Phó Chủ tịch, Trưởng Ban Tài chính và Cơ sở vật chất
4. PGS.TS. Trịnh Quốc Lập – Trưởng Ban Đào tạo và Đảm bảo chất lượng Trường
5. PGS.TS. Lê Văn Vàng – Trưởng Ban Tổ chức, Nhân sự và Pháp chế
6. TS. Trương Minh Thái – Trưởng Ban Khoa học, Hợp tác và Truyền thông
7. TS. Lê Thanh Sơn – Thư ký Hội đồng Trường, Phó Trưởng khoa phụ trách Khoa Phát triển Nông thôn

## Thành viên  
1. ThS. Dương Thị Tuyền – Ban Tổ chức, Nhân sự và Pháp chế Chủ tịch Công đoàn Trường Đại học Cần Thơ
2. Sinh viên Bùi Nguyễn Nhi Uyên – Sinh viên ngành Công nghệ thông tin K46
3. TS. Trần Văn Đạt – Ban Tổ chức, Nhân sự và Pháp chế, Q.Vụ trưởng Vụ Pháp chế, Bộ GD&ĐT
4. TS. Lê Thị Nguyệt Châu – Ban Tổ chức, Nhân sự và Pháp chế
5. ThS. Nguyễn Văn Duyệt – Ban Tài chính và Cơ sở vật chất, Trưởng Phòng Tài chính
6. PGS.TS. Lưu Thanh Đức Hải – Ban Tài chính và Cơ sở vật chất, Phó Hiệu trưởng Trường Kinh tế
7. TS. Huỳnh Anh Huy – Ban Đào tạo và Đảm bảo chất lượng, Trưởng Khoa Sư phạm
8. PGS.TS. Trịnh Quốc Lập - Trưởng ban Đào tạo và Đảm bảo chất lượng, Trưởng Khoa Ngoại Ngữ
9. TS. Lê Thanh Sơn - Phó Trưởng khoa phụ trách Khoa Phát triển Nông thôn
10. GS.TS. Trương Quốc Phú - Ban Khoa học, Hợp tác và Truyền thông, Trường Thủy sản
11. TS. Trương Minh Thái - Trưởng Ban Khoa học, Hợp tác và Truyền thông, Trưởng khoa CNPM -Trường CNTT&TT
12. TS. Trần Thanh Điền - Chánh văn phòng Trường
13. Ths. Nguyễn Minh Trí - Ban Đào tạo và Đảm bảo chất lượng, Trưởng Phòng Đào tạo
14. PGS.TS. Nguyễn Hiếu Trung - Ban Tài chính và Cơ sở vật chất, Phó Hiệu trưởng
15. PGS.TS. Lê Văn Vàng - Ban Tổ chức, Nhân sự và Pháp chế, Hiệu trưởng Trường Nông nghiệp
16. Ths. Dương Tấn Hiển - Phó Chủ tịch UBND Thành phố Cần Thơ
17. GS.TS. Nguyễn Đức Hiền - Ban Khoa học, Hợp tác và Truyền thông, Tổng Giám đốc Công ty cổ phần Vemedim
18. Ths. Đoàn Đình Duy Khương - Ban Tài chính và Cơ sở vật chất, Tổng Giám đốc điều hành Cty CP Dược Hậu Giang
19. TS. Lê Thanh Phương - Ban Khoa học, Hợp tác và Truyền thông, Giám đốc Công ty TNHH Emivest Feedmill Việt Nam
20. Ông Đồng Văn Thanh - Chủ tịch UBND Tỉnh Hậu Giang
21. Ông Châu Tuấn Hồng - Ban Đào tạo và Đảm bảo chất lượng, Giám đốc Sở GD&ĐT tỉnh Sóc Trăng
