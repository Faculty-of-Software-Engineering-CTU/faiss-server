# Ban giám hiệu Đại học Cần Thơ 2024 đến nay
1. PGS.TS. Trần Trung Tính - **Hiệu trưởng Đại học Cần Thơ**
- Lãnh đạo, quản lý toàn diện mọi hoạt động của Trường thuộc nhiệm vụ, quyền hạn của Hiệu trưởng theo Quy chế tổ chức và hoạt động của Trưòng Đại học cần Thơ và các văn bản quy phạm pháp luật có liên quan. Xây dựng và triển khai kế hoạch thực hiện chiến lược phát triển Trường, Nghị quyết của Đảng ủy, Nghị quyết của Hội đồng trường và chỉ đạo của Bộ GDĐT. Chỉ đạo triển khai việc chuyển đổi mô hình đại học theo chủ trương của Hội đồng trường và Bộ GDĐT. Chủ tịch các Hội đồng tư vấn của Trường Đại học Cần Thơ theo quy định hiện hành.

- Trực tiếp chỉ đạo các lĩnh vực: xây dựng kế hoạch phát triển Trường; thực hiện quy chế dân chủ ở cơ sở, phòng chống tham nhũng, phòng chống lãng phí; phát triển cán bộ và phát triển nguồn lực tài chính; công tác liên kết đào tạo; quản lý tài sản, xây dựng và sửa chữa cơ sở vật chất, mua sắm trang thiết bị; các hoạt động dịch vụ trong Trường; xây dựng dự án đầu tư, hợp tác trong và ngoài nước; phát triển của Trường THPT Thực hành Sư phạm, Trung tâm Giáo dục Quốc phòng và An ninh.

- Trực tiếp phụ trách các đơn vị: Văn phòng Trường, Phòng Tổ chức cán bộ, Phòng Tài chính, Phòng Thanh tra-Pháp chế, Phòng Quản trị-Thiết bị,Trung tâm Liên kết đào tạo, Trường THPT Thực hành Sư phạm, Trung tâm Giáo dục Quốc phòng và An ninh, Trung tâm Đánh giá Năng lực Ngoại ngữ, Công ty TNHH MTV KH-CN, Ban Quản lý Dự án ODA.

2. GS.TS. Trần Ngọc Hải - ****Phó Hiệu trưởng Đại học Cần Thơ****
- Phụ trách các lĩnh vực: nghiên cứu khoa học; phát triển các nhóm nghiên cứu; xuất bản, thông tin khoa học và công nghệ; phục vụ cộng đồng; công tác học sinh, sinh viên, hoạt động của Kí túc xá, mạng lưới cựu sinh viên; công tác đoàn thanh niên, hội sinh viên; đổi mới sáng tạo và khởi nghiệp, quan hệ địa phương, doanh nghiệp; Đề án Phân hiệu Trường Đại học cần Thơ tại Sóc Trăng, Khu Vĩnh Châu, Khu Măng Đen; Diễn đàn SDMD.

- Phụ trách các đơn vị: Phòng Quản lý Khoa học, Phòng Công tác sinh viên, Trung tâm tư vấn hỗ trợ và khởi nghiệp sinh viên, Văn phòng Đoàn Thanh niên Trường, Tạp chí Khoa học, Nhà xuất bản Đại học cần Thơ.

- Thực hiện các nhiệm vụ khác theo sự phân công của Hiệu trưởng.

3. PGS.TS. Nguyễn Hiếu Trung - **Phó Hiệu trưởng Đại học Cần Thơ**
- Phụ trách các lĩnh vực: công tác chính trị tư tưởng; công tác đào tạo đại học; quản lý chất lượng, cải thiện xếp hạng Trường; chuyển đổi số, truyền thông; hệ thống thư viện và học liệu.

- Phụ trách các đơn vị: Phòng Đào tạo; Trung tâm Quản lý Chất lượng, Trung tâm Thông tin &QTM, Trung tâm Học liệu, Trung tâm Công nghệ phần mềm.

- Thực hiện các nhiệm vụ khác theo sự phân công của Hiệu trưởng.

4. TS. Lê Văn Lâm - **Phó Hiệu trưởng Đại học Cần Thơ**
- Phụ trách các lĩnh vực: Đào tạo sau đại học; đào tạo quốc tế; phát triển quan hệ đối ngoại; trao đổi sinh viên với nước ngoài; phát triển chương trình, dự án đầu tư, nghiên cứu khoa học với đối tác quốc tế; xuất bản giáo trình, tài liệu; văn hóa - văn nghệ - thể dục, thể thao; họp tác quốc tế và quản lý dự án hợp tác; các chương trình “Tropical semester”, Mekong 1000; Đề án Phân hiệu Trường Đại học cần Thơ tại Hậu Giang; hoạt động Công đoàn; hoạt động Hội Cựu Chiến binh.

- Phụ trách các đơn vị: Phỏng Họp tác quốc tế, Phòng Công tác chính trị, Khoa Sau đại học, Khoa Phát triển nông thôn, Trung tâm Ngoại ngữ, Đề án Ngoại ngữ quốc gia.

- Thực hiện các nhiệm vụ khác theo sự phân công của Hiệu trưởng.