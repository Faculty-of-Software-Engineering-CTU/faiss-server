# Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU)
## Thường Trực
1. GS.TS. Trần Ngọc Hải: **Chủ tịch Hội đồng** Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
2. PGS.TS. Trịnh Quốc Lập: **Phó Chủ tịch Hội đồng** Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
3. PGS.TS. Lê Khương Ninh: **Phó Chủ tịch Hội đồng** Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
4. GS.TS. Nguyễn Thanh Phương: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
5. PGS.TS. Trần Trung Tính: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
6. PGS.TS. Lê Văn Vàng: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
7. PGS.TS. Nguyễn Hiếu Trung: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
8. TS. Lê Văn Lâm: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
9. TS. Bùi Thanh Thảo: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
10. PGS.TS. Huỳnh Anh Huy: Uỷ viên Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
11. PGS.TS. Ngô Thanh Phong: **Uỷ viên kiêm Thư ký** Hội đồng Khoa học và Đào tạo của Đại học Cần Thơ (CTU).
## Thành viên
1. GS.TS. Trần Ngọc Hải
2. PGS.TS. Trịnh Quốc Lập
3. PGS.TS. Lê Khương Ninh
4. GS.TS. Nguyễn Thanh Phương
5. PGS. TS. Trần Trung Tính
6. PGS.TS. Lê Văn Vàng
7. PGS. TS. Ngô Thanh Phong
8. PGS.TS. Nguyễn Hiếu Trung
9. PGS.TS. Nguyễn Chí Ngôn
10. GS. TS Hà Thanh Toàn
11. GS.TS. Trần Thị Thanh Hiền
12. PGS.TS. Lê Việt Dũng
13. TS. Nguyễn Văn Cương
14. PGS. TS. Phan Trung Hiền
15. TS. Lê Ngọc Triết
16. PGS. TS. Huỳnh Anh Huy
17. TS. Bùi Thanh Thảo
18. TS. Lê Thanh Sơn
19. TS. Nguyễn Hữu Hòa
20. PGS.TS. Nguyễn Văn Công
21. GS.TS. Vũ Ngọc Út
22. PGS.TS. Nguyễn Văn Thành
23. TS. Đặng Kiều Nhân
24. TS. Nguyễn Văn Hòa
25. TS. Lê Văn Lâm
26. TS. Trần Thanh Điện
27. TS. Trần Việt Trường
28. TS. Trần Ngọc Thạch
29. ThS. Trương Cảnh Tuyên
30. TS. Lâm Văn Mẫn
31. Ông Văn Tiến Thanh