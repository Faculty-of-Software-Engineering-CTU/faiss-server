# Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
## Thành viên
1.  *PGS. TS. Trần Trung Tính*: **Chủ tịch** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
2.  *PGS. TS. Nguyễn Hiếu Trung*: **Phó Chủ tịch thường trực** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
3.  *GS. TS. Trần Ngọc Hải*: **Phó Chủ tịch** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
4.  *TS. Lê Văn Lâm*: **Phó Chủ tịch** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
5.  *GS. TS. Nguyễn Thanh Phương*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
6.  *GS. TS. Hà Thanh Toàn*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
7.  *GS. TS. Trần Thị Thanh Hiền*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
8.  *PGS. TS. Lê Việt Dũng*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
9.  *TS. Phan Huy Hùng*: **Thư ký** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
10. *PGS. TS. Trần Thanh Trúc*: **Thư ký** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
11. *ThS. Nguyễn Minh Trí*: **Thư ký** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
12. *PGS. TS. Lê Nguyễn Đoan Khôi*: **Thư ký** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
13. *TS. Nguyễn Văn Cương*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
14. *TS. Ngô Bá Hùng*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
15. *PGS. TS. Trương Đông Lộc*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
16. *GS. TS. Nguyễn Trọng Ngữ*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
17. *PGS. TS. Huỳnh Anh Huy*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
18. *GS. TS. Vũ Ngọc Út*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
19. *PGS. TS. Nguyễn Văn Hòa*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
20. *TS. Lê Ngọc Triết*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
21. *PGS. TS. Ngô Thanh Phong*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
22. *TS. Bùi Thanh Thảo*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
23. *ThS. Diệp Thành Nguyên*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
24. *TS. Nguyễn Xuân Hoàng*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
25. *PGS. TS. Phương Hoàng Yến*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
26. *TS. Cao Quốc Nam*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
27. *PGS. TS. Nguyễn Thị Pha*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
28. *TS. Vũ Anh Pháp*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
29. *PGS. TS. Trần Văn Minh*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
30. *TS. Nguyễn Thanh Tường*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
31. *ThS. Nguyễn Văn Trí*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
32. *ThS. Nguyễn Văn Duyệt*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
33. *ThS. Nguyễn Thị Kim Loan*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
34. *ThS. Trịnh Trung Hưng*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
35. *ThS. Đào Phong Lâm*: **Thành viên** Hội đồng Đảm bảo chất lượng của Đại học Cần Thơ (CTU).
## Chức năng
Hội đồng Đảm bảo chất lượng Trường Đại học Cần Thơ có chức năng tư vấn cho Hiệu trưởng về chiến lược và giải pháp đảm bảo chất lượng giáo dục.
## Nhiệm vụ
1. Tư vấn cho Hiệu trưởng nhà trường trong việc xây dựng tầm nhìn về đảm bảo chất lượng, chiến lược ĐBCL trường và CTĐT.
2. Tư vấn việc lựa chọn, áp dụng các tiêu chuẩn chất lượng phù hợp, việc kiểm định chất lượng đối với nhà trường và CTĐT.
3. Tư vấn việc xây dựng và ban hành các cơ chế, chính sách, quy trình quản lý nhằm đảm bảo và khuyến khích việc duy trì và tăng cường chất lượng giáo dục.
4. Hỗ trợ Hiệu trưởng về một số mặt công tác mang tính chuyên môn liên quan đến công tác ĐBCL.
5. Tư vấn việc tăng cường các điều kiện ĐBCL.
6. Tư vấn về công tác hợp tác trong và ngoài nước trong lĩnh vực ĐBCL.
7. Tư vấn và hỗ trợ cho Hiệu trưởng thực hiện đánh giá và công nhận nội bộ chất lượng CTĐT.
8. Tư vấn việc phát triển dịch vụ liên quan đến ĐBCL và KĐCL.