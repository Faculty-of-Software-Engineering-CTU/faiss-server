# Văn phòng Trường Đại học Cần Thơ
1. *TS. Trần Thanh Điền*: **Chánh văn phòng** Văn phòng Trường Đại học Cần Thơ (CTU).
2. *ThS. Nguyễn Thị Ngọc Liên*: **Phó Chánh văn phòng** Văn phòng Trường Đại học Cần Thơ (CTU).
# Phòng Công tác Sinh viên
1. *TS. Nguyễn Thanh Tường*: **Trưởng phòng** Phòng Công tác Sinh viên thuộc Đại học Cần Thơ (CTU).
2. *ThS. Nguyễn Thanh Tuấn*: **Phó Trưởng phòng** Phòng Công tác Sinh viên thuộc Đại học Cần Thơ (CTU).
3. *ThS. Phan Quang Vinh*: **Phó Trưởng phòng** Phòng Công tác Sinh viên thuộc Đại học Cần Thơ (CTU).
4. *ThS. Trần Thiện Bình*: **Phó Trưởng phòng** Phòng Công tác Sinh viên thuộc Đại học Cần Thơ (CTU).
# Phòng Đào tạo
1. *ThS. Nguyễn Minh Trí*: **Trưởng phòng** Phòng Đào tạo thuộc Đại học Cần Thơ (CTU).
2. *ThS. Nguyễn Hứa Duy Khang*: **Phó Trưởng phòng** Phòng Đào tạo thuộc Đại học Cần Thơ (CTU).
3. *ĐH. Nguyễn Kỳ Tuấn Sơn*: **Phó Trưởng phòng** Phòng Đào tạo thuộc Đại học Cần Thơ (CTU).
# Phòng Đối ngoại và Đào tạo quốc tế
1. *PGS. TS. Hứa Thái Nhân*: **Trưởng phòng** Phòng Đối ngoại và Đào tạo quốc tế thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Văn Phạm Đan Thủy*: **Phó Trưởng phòng** Phòng Đối ngoại và Đào tạo quốc tế thuộc Đại học Cần Thơ (CTU).
# Phòng Kế hoạch và Tài chính
1. *ThS. Nguyễn Văn Duyệt*: **Trưởng phòng** Phòng Kế hoạch và Tài chính thuộc Đại học Cần Thơ (CTU).
2. *ThS. Vũ Xuân Nam*: **Phó Trưởng phòng** Phòng Kế hoạch và Tài chính thuộc Đại học Cần Thơ (CTU).
# Phòng Khoa học, Công nghệ và Đổi mới sáng tạo
1. *PGS. TS. Lê Nguyễn Đoan Khôi*: **Trưởng phòng** Phòng Khoa học, Công nghệ và Đổi mới sáng tạo thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Phạm Minh Đức*: **Phó Trưởng phòng** Phòng Khoa học, Công nghệ và Đổi mới sáng tạo thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Trần Cao Đệ*: **Phó Trưởng phòng** Phòng Khoa học, Công nghệ và Đổi mới sáng tạo thuộc Đại học Cần Thơ (CTU).
# Phòng Phát triển cơ sở vật chất và dự án
1. *ThS. Nguyễn Văn Trí*: **Trưởng phòng** Phòng Phát triển cơ sở vật chất và dự án thuộc Đại học Cần Thơ (CTU).
2. *ThS. Trần Hoàng Tuấn*: **Phó Trưởng phòng** Phòng Phát triển cơ sở vật chất và dự án thuộc Đại học Cần Thơ (CTU).
3. *ThS. Trần Chinh Phong*: **Phó Trưởng phòng** Phòng Phát triển cơ sở vật chất và dự án thuộc Đại học Cần Thơ (CTU).
# Phòng Quản lý chất lượng
1. *TS. Phan Huy Hùng*: **Trưởng phòng** Phòng Quản lý chất lượng thuộc Đại học Cần Thơ (CTU).
2. *ThS. Đào Phong Lâm*: **Phó Trưởng phòng** Phòng Quản lý chất lượng thuộc Đại học Cần Thơ (CTU).
3. *ThS. Phan Minh Nhật*: **Phó Trưởng phòng** Phòng Quản lý chất lượng thuộc Đại học Cần Thơ (CTU).
# Phòng Pháp chế
1. *TS. Nguyễn Lan Hương*: **Trưởng phòng** Phòng Pháp chế thuộc Đại học Cần Thơ (CTU).
2. *ThS. Lâm Bá Khánh Toàn*: **Phó Trưởng phòng** Phòng Pháp chế thuộc Đại học Cần Thơ (CTU).
# Phòng Tổ chức và Phát triển nhân sự
1. *ThS. Nguyễn Thị Kim Loan*: **Trưởng phòng** Phòng Tổ chức và Phát triển nhân sự thuộc Đại học Cần Thơ (CTU).
2. *ThS. Nguyễn Thanh Duy*: **Phó Trưởng phòng** Phòng Tổ chức và Phát triển nhân sự thuộc Đại học Cần Thơ (CTU).
3. *ThS. Nguyễn Văn Toàn*: **Phó Trưởng phòng** Phòng Tổ chức và Phát triển nhân sự thuộc Đại học Cần Thơ (CTU).
# Ban Quản lý Dự án Nâng cấp trường Đại học Cần Thơ
1. *ThS. Trần Hoàng Tuấn*: **Phó Giám đốc phụ trách** Ban Quản lý Dự án Nâng cấp trường Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).
2. *TS. Trần Thanh Điền*: **Phó Giám đốc** Ban Quản lý Dự án Nâng cấp trường Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).
# Trung tâm Chuyển đổi số và Truyền thông
1. *ThS. Lưu Trùng Dương*: **Giám đốc** Trung tâm Chuyển đổi số và Truyền thông thuộc Đại học Cần Thơ (CTU).
2. *ThS. Lê Thanh Sang*: **Phó Giám đốc** Trung tâm Chuyển đổi số và Truyền thông thuộc Đại học Cần Thơ (CTU).
# Trung tâm Đánh giá năng lực ngoại ngữ
1. *ThS. Lý Thị Bích Phượng*: **Phó Giám đốc phụ trách** Trung tâm Đánh giá năng lực ngoại ngữ thuộc Đại học Cần Thơ (CTU).
2. *ThS. Võ Thị Bích Thảo*: **Phó Giám đốc** Trung tâm Đánh giá năng lực ngoại ngữ thuộc Đại học Cần Thơ (CTU).
# Thư viện Đại học Cần Thơ
1. *ThS. Võ Văn Mấy Năm*: **Giám đốc** Thư viện Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).
2. *ThS. Võ Duy Bằng*: **Phó Giám đốc** Thư viện Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).
# Nhà xuất bản Đại học Cần Thơ
1. *TS. Trần Thanh Điện*: **Giám đốc** Nhà xuất bản Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).
2. *ĐH. Nguyễn Thị Kim Quyên*: **Phó Giám đốc** Nhà xuất bản Đại học Cần Thơ thuộc Đại học Cần Thơ (CTU).