# Đảng uỷ Đại học Cần Thơ
## Ban Thường Vụ
1. Nguyễn Thanh Phương — Bí thư
2. Trần Trung Tính — Phó Bí thư
3. Nguyễn Hiếu Trung — Phó Bí thư
4. Trần Ngọc Hải — Ủy viên
5. Lê Văn Lâm — Ủy viên
6. Bùi Thanh Thảo — Ủy viên, Chủ nhiệm Ủy ban Kiểm tra
7. Nguyễn Hữu Hòa — Ủy viên
8. Ngô Thanh Phong — Ủy viên

## Ban Chấp hành
1. Nguyễn Thanh Phương — Ủy viên
2. Trần Trung Tính — Ủy viên
3. Nguyễn Hiếu Trung — Ủy viên
4. Trần Ngọc Hải — Ủy viên
5. Lê Văn Lâm — Ủy viên
6. Bùi Thanh Thảo — Ủy viên
7. Nguyễn Hữu Hòa — Ủy viên
8. Ngô Thanh Phong — Ủy viên
9. Nguyễn Văn Công — Ủy viên
10. Nguyễn Văn Duyệt — Ủy viên
11. Trần Thanh Điền — Ủy viên
12. Trần Thanh Điện — Ủy viên
13. Phạm Minh Đức — Ủy viên
14. Phan Trung Hiền — Ủy viên
15. Trần Thị Tuyết Hoa — Ủy viên
16. Huỳnh Anh Huy — Ủy viên
17. Nguyễn Lan Hương — Ủy viên
18. Phạm Nguyên Khang — Ủy viên
19. Nguyễn Thị Kim Loan — Ủy viên
20. Nguyễn Chí Ngôn — Ủy viên
21. Nguyễn Văn Pha — Ủy viên
22. Trần Văn Phú — Ủy viên, Chánh Văn phòng Đảng ủy
23. Phạm Phương Tâm — Ủy viên
24. Phan Anh Tú — Ủy viên
25. Trần Văn Tỷ — Ủy viên
26. Lê Văn Vàng — Ủy viên
27. Phương Hoàng Yến — Ủy viên
