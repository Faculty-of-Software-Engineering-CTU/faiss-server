# Đảng ủy
1. *GS. TS. Nguyễn Thanh Phương*: **Bí thư** Đảng ủy Đại học Cần Thơ (CTU).
2. *PGS. TS. Trần Trung Tính*: **Phó Bí thư** Đảng ủy Đại học Cần Thơ (CTU).
3. *PGS. TS. Nguyễn Hiếu Trung*: **Phó Bí thư Đảng ủy** Đại học Cần Thơ (CTU).
4. *ĐH. Trần Văn Phú*: **Chánh Văn phòng Đảng ủy** Đại học Cần Thơ (CTU).
# Hội đồng Trường
1. *GS. TS. Nguyễn Thanh Phương*: **Chủ tịch** Hội đồng Trường Đại học Cần Thơ (CTU).
2. *PGS. TS. Nguyễn Chí Ngôn*: **Phó Chủ tịch** Hội đồng Trường Đại học Cần Thơ (CTU).
3. *TS. Lê Thanh Sơn*: **Thư ký** Hội đồng Trường Đại học Cần Thơ (CTU).
# Ban Giám hiệu Đại học Cần Thơ
1. *PGS. TS. Trần Trung Tính*: **Hiệu trưởng** Đại học Cần Thơ (CTU).
2. *PGS. TS. Nguyễn Hiếu Trung*: **Phó Hiệu trưởng** Đại học Cần Thơ (CTU).
3. *GS. TS. Trần Ngọc Hải*: **Phó Hiệu trưởng** Đại học Cần Thơ (CTU).
4. *TS. Lê Văn Lâm*: **Phó Hiệu trưởng** Đại học Cần Thơ (CTU).
# Đoàn thể
1. *ThS. Dương Thị Tuyền*: **Chủ tịch** Công đoàn trường Đại học Cần Thơ (CTU).
2. *ThS. Nguyễn Văn Pha*: **Bí thư** Đoàn Thanh niên Cộng sản Hồ Chí Minh (TNCSHCM) trường Đại học Cần Thơ (CTU).
3. *PGS. TS. Ngô Thanh Phong*: **Chủ tịch** Hội Cựu Chiến binh trường Đại học Cần Thơ (CTU).
# Trường Bách khoa
1. *TS. Nguyễn Văn Cương*: **Hiệu trưởng** Trường Bách khoa thuộc Đại học Cần Thơ (CTU).
2. *TS. Trần Thanh Hùng*: **Phó Hiệu trưởng** Trường Bách khoa thuộc Đại học Cần Thơ (CTU).
3. *ThS. Hồ Ngọc Tri Tân*: **Phó Hiệu trưởng** Trường Bách khoa thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Trần Văn Tỷ*: **Phó Hiệu trưởng** Trường Bách khoa thuộc Đại học Cần Thơ (CTU).
# Trường Công nghệ Thông tin - Truyền thông
1. *TS. Nguyễn Hữu Hòa*: **Hiệu trưởng** Trường Công nghệ Thông tin - Truyền thông thuộc Đại học Cần Thơ (CTU).
2. *GS. TS. Huỳnh Xuân Hiệp*: **Phó Hiệu trưởng** Trường Công nghệ Thông tin - Truyền thông thuộc Đại học Cần Thơ (CTU).
3. *TS. Ngô Bá Hùng*: **Phó Hiệu trưởng** Trường Công nghệ Thông tin - Truyền thông thuộc Đại học Cần Thơ (CTU).
# Trường Kinh tế
1. *PGS. TS. Lê Khương Ninh*: **Hiệu trưởng** Trường Kinh tế thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Lưu Thanh Đức Hải*: **Phó Hiệu trưởng** Trường Kinh tế thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Trương Đông Lộc*: **Phó Hiệu trưởng** Trường Kinh tế thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Phan Anh Tú*: **Phó Hiệu trưởng** Trường Kinh tế thuộc Đại học Cần Thơ (CTU).
# Trường Nông Nghiệp
1. *PGS. TS. Lê Văn Vàng*: **Hiệu trưởng** Trường Nông Nghiệp thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Châu Minh Khôi*: **Phó Hiệu trưởng** Trường Nông Nghiệp thuộc Đại học Cần Thơ (CTU).
3. *GS. TS. Nguyễn Trọng Ngữ*: **Phó Hiệu trưởng** Trường Nông Nghiệp thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Nguyễn Thị Kim Khang*: **Phó Hiệu trưởng** Trường Nông Nghiệp thuộc Đại học Cần Thơ (CTU).
# Trường Sư Phạm
1. *PGS. TS. Huỳnh Anh Huy*: **Hiệu trường** Trường Sư Phạm thuộc Đại học Cần Thơ (CTU).
2. *GS. TS. Lâm Quốc Anh*: **Phó Hiệu trưởng** Trường Sư Phạm thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Trần Văn Minh*: **Phó Hiệu trưởng** Trường Sư Phạm thuộc Đại học Cần Thơ (CTU).
4. *TS. Lê Văn Nhương*: **Phó Hiệu trưởng** Trường Sư Phạm thuộc Đại học Cần Thơ (CTU).
5. *PGS. TS. Nguyễn Văn Hòa*: **Phó Hiệu trưởng** Trường Sư Phạm thuộc Đại học Cần Thơ (CTU).
# Trường Thủy sản
1. *GS. TS. Vũ Ngọc Út*: **Hiệu trưởng** Trường Thủy sản thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Trần Minh Phú*: **Phó Hiệu trưởng** Trường Thủy sản thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Trần Thị Tuyết Hoa*: **Phó Hiệu trưởng** Trường Thủy sản thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Huỳnh Trường Giang*: **Phó Hiệu trưởng** Trường Thủy sản thuộc Đại học Cần Thơ (CTU).
# Khoa Khoa học Tự nhiên
1. *PGS. TS. Ngô Thanh Phong*: **Trưởng Khoa** Khoa Khoa học Tự nhiên thuộc Đại học Cần Thơ (CTU).
2. *GS. TS. Nguyễn Thành Tiên*: **Phó Trưởng Khoa** Khoa Khoa học Tự nhiên thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Võ Văn Tài*: **Phó Trưởng Khoa** Khoa Khoa học Tự nhiên thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Trần Thanh Mến*: **Phó Trưởng Khoa** Khoa Khoa học Tự nhiên thuộc Đại học Cần Thơ (CTU).
# Khoa Khoa học Chính trị, Xã hội và Nhân văn
1. *TS. Bùi Thanh Thảo*: **Trưởng Khoa** Khoa Khoa học Chính trị:, Xã hội và Nhân văn thuộc Đại học Cần Thơ (CTU).
2. *TS. Tạ Đức Tú*: **Phó Trưởng Khoa** Khoa Khoa học Chính trị, Xã hội và Nhân văn thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Huỳnh Văn Đà*: **Phó Trưởng Khoa** Khoa Khoa học Chính trị, Xã hội và Nhân văn thuộc Đại học Cần Thơ (CTU).
4. *TS. Phạm Văn Búa*: **Phó Trưởng Khoa phụ trách** Khoa Khoa học Chính trị, Xã hội và Nhân văn thuộc Đại học Cần Thơ (CTU).
# Khoa Luật
1. *PGS. TS. Phan Trung Hiền*: **Trưởng Khoa** Khoa Luật thuộc Đại học Cần Thơ (CTU).
2. *ThS. Diệp Thành Nguyên*: **Phó Trưởng Khoa** Khoa Luật thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Cao Nhất Linh*: **Phó Trưởng Khoa** Khoa Luật thuộc Đại học Cần Thơ (CTU).
# Khoa Môi trường và Tài nguyên Thiên nhiên
1. *GS. TS. Nguyễn Văn Công*: **Trưởng Khoa** Khoa Môi trường và Tài nguyên Thiên nhiên thuộc Đại học Cần Thơ (CTU).
2. *TS. Nguyễn Xuân Hoàng*: **Phó Trưởng Khoa** Khoa Môi trường và Tài nguyên Thiên nhiên thuộc Đại học Cần Thơ (CTU).
3. *ThS. Lê Hoàng Việt*: **Phó Trưởng Khoa** Khoa Môi trường và Tài nguyên Thiên nhiên thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Nguyễn Xuân Lộc*: **Phó Trưởng Khoa** Khoa Môi trường và Tài nguyên Thiên nhiên thuộc Đại học Cần Thơ (CTU).
# Khoa Ngoại ngữ
1. *PGS. TS. Trịnh Quốc Lập*: **Trưởng Khoa** Khoa Ngoại ngữ thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Phương Hoàng Yến*: **Phó Trưởng Khoa** Khoa Ngoại ngữ thuộc Đại học Cần Thơ (CTU).
3. *TS. Diệp Kiến Vũ*: **Phó Trưởng Khoa** Khoa Ngoại ngữ thuộc Đại học Cần Thơ (CTU).
# Cơ sở Hậu Giang
1. *TS. Cao Quốc Nam*: **Giám đốc** Cơ sở Hậu Giang thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Võ Hồng Tú*: **Phó Giám đốc** Cơ sở Hậu Giang thuộc Đại học Cần Thơ (CTU).
# Khoa Sau Đại học
1. *PGS. TS. Phạm Nguyên Khang*: **Trưởng Khoa** Khoa Sau Đại học thuộc Đại học Cần Thơ (CTU).
2. *TS. Nguyễn Đỗ Duy Phương*: **Phó Trưởng Khoa** Khoa Sau Đại học thuộc Đại học Cần Thơ (CTU).
# Trường THPT Thực hành Sư phạm
1. *PGS. TS. Trần Văn Minh*: **Hiệu trưởng** Trường THPT Thực hành Sư phạm, Trường Sư phạm thuộc Đại học Cần Thơ (CTU).
2. *ThS. Phạm Minh Khánh*: **Phó Hiệu trưởng** Trường THPT Thực hành Sư phạm, Trường Sư phạm thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Huỳnh Thị Thúy Diễm*: **Phó Hiệu trưởng** Trường THPT Thực hành Sư phạm, Trường Sư phạm thuộc Đại học Cần Thơ (CTU).
# Trung tâm Giáo dục Quốc phòng An ninh
1. *PGS. TS. Trần Trung Tính*: **Giám đốc** Trung tâm Giáo dục Quốc phòng An ninh thuộc Đại học Cần Thơ (CTU).
2. *Đại tá. TS. Cao Ngọc Báu*: **Phó Giám đốc** Trung tâm Giáo dục Quốc phòng An ninh thuộc Đại học Cần Thơ (CTU).
3. *Trung tá. ĐH. Vũ Đình Phương*: **Phó Giám đốc** Trung tâm Giáo dục Quốc phòng An ninh thuộc Đại học Cần Thơ (CTU).
# Viện Mekong
1. *PGS: TS. Văn Phạm Đăng Trí*: **Viện trưởng** Viện Mekong thuộc Đại học Cần Thơ (CTU).
2. *TS. Võ Văn Tuấn*: **Phó Viện trưởng** Viện Mekong thuộc Đại học Cần Thơ (CTU).
# Viện Công nghệ Sinh học và Thực phẩm
1. *PGS. TS. Nguyễn Văn Thành*: **Viện trưởng** Viện Công nghệ Sinh học và Thực phẩm thuộc Đại học Cần Thơ (CTU).
2. *PGS. TS. Lý Nguyễn Bình*: **Phó Viện trưởng** Viện Công nghệ Sinh học và Thực phẩm thuộc Đại học Cần Thơ (CTU).
3. *PGS. TS. Nguyễn Thị Pha*: **Phó Viện trưởng** Viện Công nghệ Sinh học và Thực phẩm thuộc Đại học Cần Thơ (CTU).
4. *PGS. TS. Nguyễn Công Hà*: **Phó Viện trưởng** Viện Công nghệ Sinh học và Thực phẩm thuộc Đại học Cần Thơ (CTU).
5. *PGS. TS. Trần Thanh Trúc*: **Phó Viện trưởng** Viện Công nghệ Sinh học và Thực phẩm thuộc Đại học Cần Thơ (CTU).
# Trung tâm Công nghệ Phần mềm
1. *ThS. Lê Hoàng Thảo*: **Giám đốc** Trung tâm Công nghệ Phần mềm thuộc Đại học Cần Thơ (CTU).
2. *TS. Trần Hoàng Việt*: **Phó Giám đốc** Trung tâm Công nghệ Phần mềm thuộc Đại học Cần Thơ (CTU).
3. *TS. Trương Xuân Việt*: **Phó Giám đốc** Trung tâm Công nghệ Phần mềm thuộc Đại học Cần Thơ (CTU).
# Trung tâm Đào tạo Liên tục
1. *PGS. TS. Phạm Phương Tâm*: **Giám đốc** Trung tâm Đào tạo Liên tục thuộc Đại học Cần Thơ (CTU).
2. *ThS. Phạm Thị Ngọc Sương*: **Phó Giám đốc** Trung tâm Đào tạo Liên tục thuộc Đại học Cần Thơ (CTU).
3. *ThS. Trịnh Trung Hưng*: **Phó Giám đốc** Trung tâm Đào tạo Liên tục thuộc Đại học Cần Thơ (CTU).
# Trung tâm Ngoại ngữ
1. *PGS. TS. Lưu Nguyễn Quốc Hưng*: **Giám đốc** Trung tâm Ngoại ngữ thuộc Đại học Cần Thơ (CTU).
2. *ThS. Võ Phạm Trinh Thư*: **Phó Giám đốc** Trung tâm Ngoại ngữ thuộc Đại học Cần Thơ (CTU).