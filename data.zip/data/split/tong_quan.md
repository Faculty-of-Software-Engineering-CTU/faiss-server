# Tổng quan - Đại học Cần Thơ
## Giới thiệu chung
Đồng bằng Sông Cửu Long (ĐBSCL), có diện tích khoảng 4 triệu hécta đất tự nhiên với trên 17 triệu dân, là vùng sản xuất nông nghiệp lớn nhất cả nước, được ví như vựa lúa của Việt Nam. Ngoài nguồn lương thực, ĐBSCL còn có nguồn lợi về cây ăn quả, thủy hải sản xuất khẩu với trữ lượng lớn và đa dạng về chủng loại. Đây là vùng đất mới trù phú, cảnh quan xinh đẹp, cây trái tốt tươi quanh năm.

Trong những năm qua, nhiều chính sách của Đảng và Nhà nước đã tác động tích cực, làm đổi thay lớn về sản xuất và phát triển nông nghiệp ở ĐBSCL mang lại sự thịnh vượng chung cho toàn vùng. Bước vào thiên niên kỷ mới, với yêu cầu Công nghiêp hóa - Hiện đại hóa đất nước, nhiều vấn đề về cơ sở lý luận và thực tiễn khoa học, việc qui hoạch chiến lược phát triển của vùng đặt ra những câu hỏi bức bách cho các nhà khoa học và chính quyền các cấp tham gia nghiên cứu, lý giải nhằm đầu tư, khai thác và sử dụng có hiệu quả nhất nguồn nhân lực và tài nguyên phong phú, đa dạng của vùng.

Đại học Cần Thơ (ĐHCT), cơ sở đào tạo đại học và sau đại học trọng điểm của Nhà nước ở ĐBSCL, là trung tâm văn hóa - khoa học kỹ thuật của vùng. ĐHCT đã không ngừng hoàn thiện và phát triển, từ một số ít ngành đào tạo ban đầu đồng thời củng cố, phát triển thành một đại học đa ngành đa lĩnh vực. Hiện tại, Trường có 121 chương trình đào tạo (106 chương trình đại trà, 2 chương trình tiên tiến, 13 chương trình chất lượng cao), 58 chương trình thạc sĩ (2 chương trình quốc tế) và 22 chương trình tiến sĩ (1 chương trình quốc tế). Bên cạnh đó, công tác bảo đảm chất lượng luôn được ĐHCT chú trọng. Cụ thể, ĐHCT đã thực hiện kiểm định chất lượng 24 chương trình đào tạo, gồm 16 chương trình theo tiêu chuẩn của Bộ Giáo dục và Đào tạo và 8 chương trình theo tiêu chuẩn AUN-QA. Tính đến năm 2024, ĐHCT có 28 chương trình đạt chất lượng trong nước và 34 chương trình đạt chuẩn chất lượng của AUN-QA.

Nhiệm vụ chính của ĐHCT là đào tạo, nghiên cứu khoa học (NCKH), chuyển giao công nghệ phục vụ phát triển kinh tế - xã hội trong vùng. Song song với công tác đào tạo, ĐHCT đã tham gia tích cực các chương trình NCKH, ứng dụng những thành tựu khoa học kỹ thuật nhằm giải quyết các vấn đề về khoa học, công nghệ, kinh tế, văn hoá và xã hội của vùng. Từ những kết quả của các công trình NCKH và hợp tác quốc tế, ĐHCT đã tạo ra nhiều sản phẩm, qui trình công nghệ phục vụ sản xuất, đời sống và xuất khẩu, tạo được uy tín trên thị trường trong nước và quốc tế.

ĐHCT tranh thủ được sự hỗ trợ tích cực của chính quyền địa phương ĐBSCL trong các lĩnh vực đào tạo, hợp tác khoa học kỹ thuật và chuyển giao công nghệ. ĐHCT đã mở rộng quan hệ hợp tác khoa học kỹ thuật với nhiều tổ chức quốc tế, trường đại học và viện nghiên cứu trên thế giới. Thông qua các chương trình hợp tác, năng lực quản lý và chuyên môn của đội ngũ cán bộ được nâng cao, cơ sở vật chất, trang thiết bị thí nghiệm, tài liệu thông tin khoa học được bổ sung.

Cơ sở vật chất của ĐHCT tọa lạc trên 6 địa điểm: Khu I, Khu II, Khu III, Khu Hòa An, Khu Măng Đen, Khu Vĩnh Châu.

## Khẩu hiệu
Tầm nhìn (Vision) - Đại học Cần Thơ là nơi hội tụ, giao thoa và sản sinh tri thức - văn hóa - khoa học - công nghệ, tác động vào phát triển xã hội bền vững.

Sứ mệnh (Mission) - Đại học Cần Thơ là nơi đào tạo con người tinh hoa trong môi trường học tập khai phóng, nghiên cứu khoa học và chuyển giao công nghệ đương đại, phát triển xã hội thịnh vượng.

Giá trị cốt lõi (Core Values) - Đồng thuận – Tận tâm – Chuẩn mực - Sáng tạo

## Chiến lược phát triển
Thực hiện sứ mệnh của mình, trong kế hoạch chiến lược đến năm 2025, Đai học Cần Thơ sẽ tập trung vào ba trụ cột chính có mối quan hệ tương tác với nhau: Phục vụ xã hội, Nghiên cứu khoa học và phát triển, Dạy và học.

## Chính sách đảm bảo chất lượng
Nhận thức tầm quan trọng của nhu cầu nguồn nhân lực chất lượng cao và sự cạnh tranh mạnh mẽ về chất lượng đào tạo trong bối cảnh phát triển mới của quốc gia và quốc tế, Đại học Cần Thơ cam kết đảm bảo chất lượng thông qua thường xuyên đổi mới và hội nhập trong đào tạo; sáng tạo và năng động trong nghiên cứu và chuyển giao công nghệ; gắn lý thuyết với thực hành để trang bị đầy đủ kiến thức và kỹ năng cho người học khi ra trường đạt hiệu quả cao trong công việc, có năng lực lãnh đạo và thích ứng với thay đổi.

Đai học Cần Thơ cam kết xây dựng hệ thống quản trị hiệu quả, chuyên nghiệp, trách nhiệm, sáng tạo và luôn đổi mới. Hoạt động quản lý của Đại học Cần Thơ sẽ được quy trình hóa, tin học hóa, áp dụng các phương thức quản trị cập nhật và được giám sát, đánh giá thường xuyên.

## Mục tiêu giáo dục
Đào tạo nhân lực trình độ cao, nâng cao dân trí, bồi dưỡng nhân tài; nghiên cứu khoa học và công nghệ tạo ra tri thức, sản phẩm mới và phục vụ cộng đồng đáp ứng nhu cầu phát triển kinh tế – xã hội, bảo đảm quốc phòng, an ninh, hội nhập quốc tế.

Đào tạo người học phát triển toàn diện về đức, trí, thể, mỹ; có tri thức, kỹ năng, trách nhiệm nghề nghiệp; có khả năng nắm bắt tiến bộ khoa học và công nghệ tương xứng với trình độ đào tạo, khả năng tự học, sáng tạo, thích nghi với môi trường làm việc; có tinh thần lập nghiệp, có ý thức phục vụ nhân dân.

## Hình thành và phát triển
### Thời kỳ Viện Đại học Cần Thơ (1966-1975)
Được thành lập ngày 31 tháng 03 năm 1966, Viện Đại học Cần Thơ có bốn khoa: Khoa học, Luật khoa và Khoa học Xã hội, Văn khoa, Sư phạm (có Trường Trung học Kiểu mẫu) đào tạo hệ Cử nhân, Trường Cao đẳng Nông nghiệp đào tạo hệ kỹ sư và Trung tâm Sinh ngữ giảng dạy chương trình ngoại ngữ cho sinh viên.

Cơ sở vật chất của Viện Đại học Cần Thơ tọa lạc trên 4 địa điểm:
-  Tòa Viện trưởng (Số 5, đại lộ Hoà Bình): là nơi tâp trung các bộ phận hành chính của Viện.
-  Khu I (đường 30/4): diện tích hơn 5 ha là khu nhà ở, lưu trú xá nữ sinh viên, Trường Trung học Kiểu mẫu, Trường Cao đẳng Nông nghiệp và nhà làm việc của các khoa.
-  Khu II: (đường 3/2): diện tích 87 ha, là khu nhà học chính của Trường.
-  Khu III: (số 1, Lý Tự Trọng): diện tích 0,65 ha, là cơ sở đào tạo đầu tiên gồm khoa Khoa học và Thư viện.

### Trường Đại học Cần Thơ giai đoạn sau năm 1975
Viện Đại học Cần Thơ được đổi thành ĐHCT. Lúc này, chương trình đào tạo và sinh viên cũ của Khoa Sư phạm và Cao đẳng Nông nghiệp được tiếp tục đào tạo tại Khoa Sư phạm Tự nhiên và Khoa Nông nghiệp của ĐHCT. Sinh viên của các khoa khác hoặc được gởi lên các trường đại học ở Thành phố Hồ Chí Minh hoặc được chuyển vào các chuyên ngành đang đào tạo tại Trường.

Sau năm 1975, Khoa Sư phạm được tách thành Khoa Sư phạm Tự nhiên và Khoa Sư phạm Xã hội đào tạo giáo viên phổ thông trung học gồm Toán học, Vật lý học, Hóa học, Sinh vật học, Văn học, Lịch sử, Địa lý, và Ngoại ngữ. Sau đó mở rộng thành 5 Khoa: Toán - Lý (1980), Hóa - Sinh (1980), Sử - Địa (1982), Ngữ văn (1983) và Ngoại ngữ (1983).

Trường Cao đẳng Nông nghiệp được đổi tên thành Khoa Nông nghiệp, đào tạo 2 ngành Trồng trọt và Chăn nuôi. Đến năm 1979, Khoa Nông nghiệp được mở rộng thành 7 Khoa: Trồng trọt (1977), Chăn nuôi - Thú y (1978), Thủy nông và Cải tạo đất (1978), Cơ khí Nông nghiệp (1978), Chế biến và Bảo quản Nông sản (1978), Kinh tế Nông nghiệp (1979), và Thủy sản (1979).

Năm 1978, Khoa Đại học Tại chức được thành lập, có nhiệm vụ quản lý và thiết kế chương trình bồi dưỡng và đào tạo giáo viên phổ thông trung học và kỹ sư thực hành chỉ đạo sản xuất cho các tỉnh ĐBSCL. Thời gian đào tạo là 5 năm. Từ năm 1981 do yêu cầu của các địa phương, công tác đào tạo tại chức cần được mở rộng hơn và Trường đã liên kết với các tỉnh mở các trung tâm Đào tạo - Bồi dưỡng Đại học Tại chức mà tên gọi hiện nay là Trung tâm Giáo dục Thường xuyên: Tiền Giang - Long An - Bến Tre, Vĩnh Long - Đồng Tháp, Cần Thơ, An Giang, Sóc Trăng, Trà Vinh, Kiên Giang và Minh Hải.

Năm 1987, để phục vụ phát triển kinh tế thị trường phù hợp với chính sách đổi mới của Đảng và Nhà nước, Khoa Kinh tế Nông Nghiệp đã liên kết với Trường Đại học Kinh tế Thành phố Hồ Chí Minh mở thêm 4 ngành đào tạo Cử nhân Kinh tế: Kinh tế Tài chính - Tín dụng, Kinh tế Kế toán Tổng hợp, Kinh tế Ngoại thương và Quản trị Kinh doanh. Tương tự, năm 1988, Khoa Thủy nông đã mở thêm hai ngành đào tạo mới là Thủy công và Công thôn đáp ứng nhu cầu xây dựng nhà cửa và cầu đường nông thôn ở ĐBSCL.

Năm 1990, Khoa Toán Lý mở hệ cao đẳng đào tạo 2 ngành: Điện tử và Tin học và nâng cấp xưởng điện tử thành Trung tâm Điện tử - Tin học.

Ngoài việc thành lập và phát triển các khoa, ĐHCT còn tổ chức các Trung tâm NCKH nhằm kết hợp có hiệu quả 3 nhiệm vụ Đào tạo - NCKH - Lao động sản xuất. Từ năm 1985 đến năm 1992 có 7 Trung tâm được thành lập: Trung tâm Nghiên cứu và Phát triển Công nghệ Sinh học (1985), Năng lượng mới (1987), Nghiên cứu và Phát triển Hệ thống Canh tác ĐBSCL (1988), Điện tử - Tin học (1990), Nghiên cứu và Phát triển Tôm-Artemia (1991), Ngoại ngữ (1991), Thông tin Khoa học & Công nghệ (1992).

Tháng 4 năm 2003, Khoa Y- Nha - Dược được tách ra để thành lập Trường Đại học Y- Dược trực thuộc Bộ Y Tế.

Trong suốt quá trình hình thành và phát triển, Trường luôn nhận được sự quan tâm, hỗ trợ của Nhà nước, Chính phủ và Bộ chủ quản. 

### Đại học Cần Thơ từ ngày 15/7/2025
Ngày 15/7/2025, Thủ tướng Chính phủ đã ký Quyết định số 1531/QĐ-TTg về việc chuyển Trường Đại học Cần Thơ thành Đại học Cần Thơ – đại học vùng của quốc gia, có chức năng đào tạo, nghiên cứu và chuyển giao công nghệ phục vụ phát triển kinh tế - xã hội vùng Đồng bằng sông Cửu Long và quốc gia. Đây không chỉ là bước chuyển đổi về mặt tổ chức, mà còn là cột mốc quan trọng, khẳng định vai trò trung tâm học thuật, nghiên cứu và sáng tạo của Trường trong hệ thống giáo dục đại học Việt Nam.

Với định hướng chiến lược trở thành trung tâm văn hóa - tri thức, nghiên cứu - đổi mới sáng tạo của vùng Đồng bằng sông Cửu Long và khát vọng vươn cao vì cộng đồng, Đại học Cần Thơ cam kết phát huy tối đa nguồn lực nội tại, thúc đẩy hợp tác quốc tế, đầu tư phát triển cơ sở vật chất hiện đại, nâng cao chất lượng đội ngũ và hoàn thiện mô hình quản trị tiên tiến; tạo đòn bẩy để nâng tầm vị thế Đại học Cần Thơ trên bản đồ giáo dục đại học khu vực và thế giới, xứng đáng với niềm tin và kỳ vọng của Đảng, Nhà nước và Nhân dân vùng Đồng bằng sông Cửu Long.

Trong kỷ nguyên của tri thức, công nghệ và hội nhập sâu rộng, với triết lý giáo dục “Cộng đồng - Toàn diện - Ưu việt”, Đại học Cần Thơ đang nỗ lực hiện thực hóa tầm nhìn trở thành nơi hội tụ của tri thức, sáng tạo và trách nhiệm. Đại học Cần Thơ sẽ tiếp tục là mắt xích trọng yếu trong hệ sinh thái giáo dục - nghiên cứu - đổi mới sáng tạo của cả vùng và cả nước, đóng góp thiết thực cho sự phát triển bền vững và thịnh vượng, đồng hành cùng đất nước bước vào thời kỳ phát triển nhanh, bền vững và hội nhập sâu rộng.

## Lĩnh vực hoạt động
### Đào tạo
Hiện tại, Đại học Cần Thơ có 121 chương trình đào tạo (106 chương trình đại trà, 2 chương trình tiên tiến, 13 chương trình chất lượng cao), 58 chương trình thạc sĩ (2 chương trình quốc tế) và 22 chương trình tiến sĩ (1 chương trình quốc tế). Bên cạnh đó, công tác bảo đảm chất lượng luôn được Đại học Cần Thơ chú trọng. Cụ thể, Trường đã thực hiện kiểm định chất lượng 24 chương trình đào tạo, gồm 16 chương trình theo tiêu chuẩn của Bộ Giáo dục và Đào tạo và 8 chương trình theo tiêu chuẩn AUN-QA. Hàng năm, Trường còn tiếp nhận sinh viên từ các truờng đại học nước ngoài (Hoa Kỳ, Bỉ, Nhật Bản,...) đến học tại Trường trong khuôn khổ thỏa thuận hợp tác giữa hai bên.

Thời gian đào tạo tại Đại học Cần Thơ từ 4 - 5 năm cho các chương trình đào tạo cử nhân, kỹ sư, theo hệ thống tín chỉ. Chương trình đào tạo gồm ba học kỳ đầu tiên dành cho các môn chung của tất cả các khối ngành và các môn cơ bản cho từng khối ngành; các học kỳ còn lại dành cho các kiến thức cơ sở và chuyên môn cho chuyên ngành đào tạo.

Chất lượng đào tạo của Trường không ngừng được nâng cao, các phương tiện phục vụ nhu cầu học tập cho sinh viên đã tương đối hoàn chỉnh, giảng viên đã áp dụng nhiều phương pháp giảng dạy mới phù hợp.

### Nghiên cứu khoa học
Đại học Cần Thơ đã chủ trì nhiều đề tài cấp Nhà nước, cấp Bộ, cấp Trường, mở rộng hợp đồng NCKH và chuyển giao tiến bộ khoa học và kỹ thuật phục vụ kinh tế xã hội vùng ĐBSCL và trong cả nước.

Các chương trình nghiên cứu quốc gia có liên kết với các trường đại học trong và ngoài nước được thực hiện trên nhiều địa bàn ở ĐBSCL và trong cả nước đã đem lại hiệu quả kinh tế và xã hội cao như các chương trình: Điều tra cơ bản vùng ĐBSCL, nghiên cứu đất phèn, nghiên cứu và sản xuất Artemia - Tôm, nghiên cứu kỹ thuật nuôi cá nước ngọt, vi sinh vật cố định đạm, công nghệ sinh học, chế biến và bảo quản nông sản, nghiên cứu các mô hình hệ thống canh tác và tuyển chọn các giống lúa thích nghi, phòng trừ dịch hại trên cây trồng, cải thiện hoa màu, kinh tế vườn, phát triển và chuyển giao kỹ thuật chăn nuôi - thú y, mô hình VACB, cơ khí nông nghiệp và cơ khí phục vụ sau thu hoạch, qui hoạch tổng thể giáo dục ĐBSCL, phương pháp dạy và học, các mô hình hình sản xuất mang lại hiệu quả kinh tế, thị trường chứng khoán... Các chương trình này đã tranh thủ được sự hỗ trợ của các địa phương vùng ĐBSCL và nguồn tài trợ từ các tổ chức quốc tế và nhiều tổ chức, trường đại học khác.

### Hợp tác trong nước
Đại học Cần Thơ đã ký kết hợp tác toàn diện về nghiên cứu khoa học và đào tạo với Viện Nghiên cứu Lúa ĐBSCL và Viện Nghiên cứu Cây ăn quả Miền Nam. Trường cũng đã Thỏa thuận hợp tác với hầu hết UBND các tỉnh vùng BĐBSCL trong công tác chuyển giao khoa học kỹ thuật. Đặc biệt, Trường đã Ký kết Thỏa thuận hợp tác trong đào tạo và NCKH với 10 trường Đại học khối Nông-Lâm-Ngư trong cả nước.

Trường đang tập trung mở rộng năng lực đào tạo sau đại học nhằm giúp giải quyết nhu cầu bức thiết phải nâng cấp nhanh lực lượng cán bộ giảng dạy của Trường, các trường đại học, cao đẳng cán bộ nghiên cứu thuộc các tỉnh vùng ĐBSCL. Tăng cường đào tạo ngắn hạn, mở các lớp tập huấn, chuyển giao khoa học công nghệ cho cán bộ và nhân dân trong vùng... Chuyển mạnh từ đào tạo theo khả năng sang đào tạo theo nhu cầu của doanh nghiệp, của xã hội.

Mối quan hệ giữa Đại học Cần Thơ với các tỉnh trong vùng ngày càng được thắt chặt trong sự hợp tác, hỗ trợ lẫn nhau. Sự ưu ái của các tỉnh trong vùng, đặc biệt là của Thành phố Cần Thơ đối với Đại học Cần Thơ là một nền tảng vững chắc cho sự phát triển bền vững của Trường.
